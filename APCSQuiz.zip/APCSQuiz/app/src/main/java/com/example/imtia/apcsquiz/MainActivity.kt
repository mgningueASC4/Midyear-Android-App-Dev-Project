package com.example.imtia.apcsquiz

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import com.example.imtia.apcsquiz.R.layout.activity_main2

class MainActivity : AppCompatActivity() {
    val b1 = findViewById<Button>(R.id.button1)
    val b2 = findViewById<Button>(R.id.button2)
    val b3 = findViewById<Button>(R.id.button3)
    val b4 = findViewById<Button>(R.id.button4)
    val b5 = findViewById<Button>(R.id.button5)
    val b6 = findViewById<Button>(R.id.button6)
    val b7 = findViewById<Button>(R.id.button7)
    val b8 = findViewById<Button>(R.id.button8)
    val b9 = findViewById<Button>(R.id.button9)
    val b10 = findViewById<Button>(R.id.button10)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun menuBtnAction(v: View){
        val i:Intent = Intent(this,Main2Activity::class.java)
        startActivity(i)
    }
}
